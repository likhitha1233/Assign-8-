// memtest.c - Q2: physical memory statistics
#include "types.h"
#include "stat.h"
#include "user.h"
#include "meminfo.h"

static void
show(char *tag)
{
  struct meminfo mi;
  getmeminfo(&mi);
  printf(1, "%s: total=%d free=%d user_pages=%d pt_pages=%d\n",
         tag, mi.total_pages, mi.free_pages, mi.user_pages, mi.pt_pages);
}

static int
freepages(void)
{
  struct meminfo mi;
  getmeminfo(&mi);
  return mi.free_pages;
}

int
main(int argc, char *argv[])
{
  int i, pid, before, during, after;
  char *p;

  show("start                 ");

  // grow the heap by 100 pages; touch every page so frames are really used
  // (with lazy sbrk, untouched pages would not consume memory)
  p = sbrk(100 * 4096);
  show("after sbrk (untouched)");
  for(i = 0; i < 100; i++)
    p[i * 4096] = 1;
  show("after touching 100 pg ");

  p = malloc(40 * 4096);
  for(i = 0; i < 40; i++)
    p[i * 4096] = 1;
  show("after malloc 40 pages ");

  // fork a child and see how free pages change
  before = freepages();
  printf(1, "free before fork = %d\n", before);
  pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0){
    during = freepages();
    printf(1, "child : free=%d, fork consumed %d pages\n", during, before - during);
    exit();
  }
  wait();
  after = freepages();
  printf(1, "free after child exit + wait = %d\n", after);
  if(after == before)
    printf(1, "NO LEAK: free pages returned to %d\n", before);
  else
    printf(1, "LEAK: before=%d after=%d\n", before, after);
  exit();
}
