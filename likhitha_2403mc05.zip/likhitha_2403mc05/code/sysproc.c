#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "meminfo.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return myproc()->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = myproc()->sz;
  if(n > 0){
    // Q4: lazy allocation - only enlarge the logical size; frames are
    // allocated by the page-fault handler when a page is first touched.
    if((uint)n > KERNBASE - addr)
      return -1;
    myproc()->sz += n;
  } else if(n < 0){
    // shrinking still frees the pages that were really allocated
    if((uint)(-n) > addr)
      return -1;
    if(growproc(n) < 0)
      return -1;
  }
  return addr;
}

// Q1: translate a virtual address of the calling process
int
sys_va2pa(void)
{
  int va;

  if(argint(0, &va) < 0)
    return -1;
  return va2pa((uint)va);
}

// Q2: fill a struct meminfo for the caller
int
sys_getmeminfo(void)
{
  struct meminfo *mi;
  struct proc *p = myproc();

  if(argptr(0, (char**)&mi, sizeof(*mi)) < 0)
    return -1;
  mi->total_pages = ktotalpages();
  mi->free_pages  = kfreepages();
  mi->user_pages  = p->sz / PGSIZE;
  mi->pt_pages    = countptpages(p->pgdir);
  return 0;
}

// Q3: dump the page directory / page tables of the caller
int
sys_vmprint(void)
{
  return vmprint();
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(myproc()->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
