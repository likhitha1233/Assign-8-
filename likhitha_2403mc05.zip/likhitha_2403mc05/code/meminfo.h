// Q2: structure filled in by getmeminfo()
struct meminfo {
  int total_pages;   // frames managed by the kernel allocator
  int free_pages;    // frames currently on the free list
  int user_pages;    // sz / PGSIZE of the calling process
  int pt_pages;      // frames used by its page tables (page directory + all page tables)
};
