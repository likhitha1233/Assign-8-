// lazytest.c - Q4: lazy allocation (demand paging for the heap)
#include "types.h"
#include "stat.h"
#include "user.h"
#include "fcntl.h"
#include "meminfo.h"

#define MB (1024 * 1024)
#define PG 4096

static void
show(char *tag)
{
  struct meminfo mi;
  getmeminfo(&mi);
  printf(1, "%s: free=%d user_pages=%d pt_pages=%d\n",
         tag, mi.free_pages, mi.user_pages, mi.pt_pages);
}

// run f in a child and report whether it was killed
static void
expect_kill(char *name, int kind)
{
  int pid = fork();
  if(pid == 0){
    char local;
    char *p = sbrk(0);
    volatile char *bad;
    if(kind == 0)
      bad = p + 100 * PG;                          // address >= sz
    else
      bad = (char*)(((uint)&local & ~(PG - 1)) - PG);   // stack guard page
    *bad = 1;
    printf(1, "FAIL: %s was not killed\n", name);
    exit();
  }
  wait();
  printf(1, "%s: child killed, parent still running\n", name);
}

int
main(int argc, char *argv[])
{
  char *p;
  int i, pid, fd, n;
  int base, basept;
  int pipefd[2];

  show("start                     ");
  {
    struct meminfo mi;
    getmeminfo(&mi);
    base = mi.free_pages;
    basept = mi.pt_pages;
  }

  p = sbrk(32 * MB);
  if(p == (char*)-1){
    printf(1, "sbrk(32MB) failed\n");
    exit();
  }
  show("after sbrk(32MB)          ");

  // touch only 5 widely spaced pages out of 8192
  for(i = 0; i < 5; i++)
    p[i * 1600 * PG] = i + 1;
  show("after touching 5 pages    ");
  for(i = 0; i < 5; i++)
    if(p[i * 1600 * PG] != i + 1)
      printf(1, "FAIL: data mismatch\n");
  printf(1, "untouched page reads as %d (zero-filled)\n", p[PG]);

  // fork with holes in the address space (copyuvm must skip them)
  pid = fork();
  if(pid == 0){
    p[3 * 1600 * PG] = 77;
    printf(1, "child: wrote and read %d at 0x%x\n", p[3 * 1600 * PG], p + 3 * 1600 * PG);
    exit();
  }
  wait();
  printf(1, "fork/exit with sparse heap OK\n");

  // system calls using untouched buffers
  fd = open("README", O_RDONLY);
  n = read(fd, p + 7000 * PG + 100, 200);          // untouched page
  printf(1, "read() into untouched page returned %d\n", n);
  close(fd);
  n = write(1, p + 6000 * PG, 4);                  // untouched page, writes 4 NULs
  printf(1, "\nwrite() from untouched page returned %d\n", n);
  pipe(pipefd);
  write(pipefd[1], "hello", 5);
  n = read(pipefd[0], p + 5000 * PG, 5);           // untouched page
  printf(1, "pipe read into untouched page: %d bytes '%s'\n", n, p + 5000 * PG);
  close(pipefd[0]);
  close(pipefd[1]);
  show("after syscall tests       ");

  // invalid accesses kill only the offender
  expect_kill("access beyond sz", 0);
  expect_kill("stack guard page access", 1);

  // shrinking frees only the pages that were really allocated
  sbrk(-32 * MB);
  show("after sbrk(-32MB)         ");
  {
    struct meminfo mi;
    getmeminfo(&mi);
    // xv6 keeps page-table pages until the process exits, so they are the
    // only frames allowed to remain allocated after the heap is shrunk
    int held = base - mi.free_pages;
    int ptgrowth = mi.pt_pages - basept;
    printf(1, "free now %d, at start %d: %d frames held, page tables grew by %d -> %s\n",
           mi.free_pages, base, held, ptgrowth,
           held == ptgrowth ? "NO LEAK (only page tables remain until exit)" : "LEAK");
  }
  exit();
}
