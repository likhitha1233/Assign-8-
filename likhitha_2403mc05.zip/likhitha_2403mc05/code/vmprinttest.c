// vmprinttest.c - Q3: dump the page table of the running process
#include "types.h"
#include "stat.h"
#include "user.h"

static void
check(char *tag)
{
  int sz = (int)sbrk(0);
  int ua = vmprint();
  printf(1, "[%s] sz/PGSIZE=%d user-accessible=%d (expected sz/PGSIZE-1=%d) %s\n\n",
         tag, sz / 4096, ua, sz / 4096 - 1,
         ua == sz / 4096 - 1 ? "OK" : "MISMATCH");
}

int
main(int argc, char *argv[])
{
  char *p;
  int i;

  printf(1, "==== 1. at start-up ====\n");
  check("start");

  printf(1, "==== 2. after sbrk(8*4096) ====\n");
  p = sbrk(8 * 4096);
  for(i = 0; i < 8; i++)          // touch pages: sbrk is lazy (Q4)
    p[i * 4096] = 1;
  check("grown");

  printf(1, "==== 3. after sbrk(-4096) ====\n");
  sbrk(-4096);
  check("shrunk");
  exit();
}
