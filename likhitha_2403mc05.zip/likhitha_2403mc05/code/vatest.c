// vatest.c - Q1: virtual to physical address translation
#include "types.h"
#include "stat.h"
#include "user.h"

int g = 42;                       // global variable

static void
show(char *name, int va)
{
  int pa = va2pa(va);
  if(pa == -1)
    printf(1, "%s: va=0x%x pa=-1 (not mapped / not user accessible)\n\n", name, va);
  else
    printf(1, "%s: va=0x%x pa=0x%x\n\n", name, va, pa);
}

int
main(int argc, char *argv[])
{
  int local = 7;                  // lives on the user stack
  int *heap = (int*)malloc(100);  // lives on the heap
  int pid;

  *heap = 1;
  show("global", (int)&g);
  show("local ", (int)&local);
  show("malloc", (int)heap);
  show("0x7FFFFFFF", 0x7FFFFFFF);
  show("0x80100000 (kernel)", 0x80100000);

  // fork: same VA, different PA (xv6 copies the pages)
  printf(1, "---- fork test ----\n");
  pid = fork();
  if(pid < 0){
    printf(1, "fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "child : ");
    show("global", (int)&g);
    g = 99;                       // write in child
    printf(1, "child : g=%d\n", g);
    exit();
  }
  wait();
  printf(1, "parent: ");
  show("global", (int)&g);
  printf(1, "parent: g=%d (unchanged by child)\n", g);
  exit();
}
